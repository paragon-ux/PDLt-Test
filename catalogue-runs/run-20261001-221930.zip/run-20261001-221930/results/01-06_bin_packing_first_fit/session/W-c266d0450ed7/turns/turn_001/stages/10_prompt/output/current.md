C = 10
Items = [5, 5, 5, 3, 3, 3, 7, 7]
First Fit algorithm
optimal packing
self-test
RUN the First Fit algorithm on the items in the given arrival order Items = [5, 5, 5, 3, 3, 3, 7, 7] with bin capacity C = 10
REPORT the resulting packing from the First Fit algorithm
FIND an optimal packing that minimizes the number of bins for the same items and capacity
REPORT the optimal packing
CALCULATE the gap between the First Fit packing and the optimal packing
EXPLAIN why the arrival order causes the First Fit algorithm to use more bins than the optimal packing
INCLUDE a self-test that verifies both packings use each item exactly once and respect the capacity constraint
