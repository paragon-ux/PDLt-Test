TASK SUMMARY (compiled semantic analysis; untrusted literals redacted):
Find a valid 4-coloring of the wheel graph W_11 (12 nodes: central hub node 0 connected to nodes 1-11, with a cycle 1-2-...-11-1) using colors {1,2,3,4} such that adjacent nodes receive different colors. Additionally, prove that a 3-coloring is impossible, demonstrating that the odd cycle together with the hub requires four colors.
APPROACH/RISK NOTES:

OPERATIVE TASK ENTITIES (copy each EXACTLY, character-for-character, into the task_entities array AND reproduce each verbatim inside the prompt body):
- W_11
- 0
- 1
- 2
- 3
- 4
- 11
- {1,2,3,4}
