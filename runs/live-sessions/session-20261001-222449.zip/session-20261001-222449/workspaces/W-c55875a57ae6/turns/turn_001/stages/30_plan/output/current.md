DEFINE L_min as the length of the shortest piece resulting from two random cuts on a unit-length stick
DEFINE L_max as the length of the longest piece resulting from the same cuts
EXPRESS the joint distribution of the three piece lengths derived from the ordered cut points
FORMULATE the condition L_min / L_max >= 1/4 in terms of the piece lengths
SET UP the integral over the region of the joint distribution where the condition holds
DERIVE a symbolic expression for the probability as the integral of the joint density over that region
RETURN the resulting symbolic probability expression
